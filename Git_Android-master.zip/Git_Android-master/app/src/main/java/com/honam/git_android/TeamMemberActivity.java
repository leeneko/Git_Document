package com.honam.git_android;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TeamMemberActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView memberImage;
    private Button btn_main_page;
    private TextView memberName, memberIntroduce, memberRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_member);

        memberImage = (ImageView) findViewById(R.id.team_member_image);

        btn_main_page = (Button) findViewById(R.id.btn_member_main_page);
        btn_main_page.setOnClickListener(this);

        memberName = (TextView) findViewById(R.id.team_member_name);
        memberIntroduce = (TextView) findViewById(R.id.team_member_introduce);
        memberRole = (TextView) findViewById(R.id.team_member_role);
        
        /* START : 아래에 내용을 입력 하시오. */







        /* END : 아래에 내용을 입력 하시오. */

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_member_main_page:
                startActivity(new Intent(TeamMemberActivity.this, MainActivity.class));
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

}
