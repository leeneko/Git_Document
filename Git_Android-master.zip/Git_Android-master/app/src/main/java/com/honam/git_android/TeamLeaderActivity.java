package com.honam.git_android;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TeamLeaderActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageView leaderImage;
    private Button btn_main_page;
    private TextView leaderName, leaderIntroduce, leaderRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_leader);

        leaderImage = (ImageView) findViewById(R.id.team_leader_image);

        btn_main_page = (Button) findViewById(R.id.btn_leader_main_page);
        btn_main_page.setOnClickListener(this);

        leaderName = (TextView) findViewById(R.id.team_leader_name);
        leaderIntroduce = (TextView) findViewById(R.id.team_leader_introduce);
        leaderRole = (TextView) findViewById(R.id.team_leader_role);

        /* START : 아래에 내용을 입력 하시오. */







        /* END : 아래에 내용을 입력 하시오. */

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_leader_main_page:
                startActivity(new Intent(TeamLeaderActivity.this, MainActivity.class));
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
